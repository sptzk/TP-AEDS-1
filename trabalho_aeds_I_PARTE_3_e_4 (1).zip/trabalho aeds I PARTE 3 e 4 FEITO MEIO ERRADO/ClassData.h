#include <iostream>
#include <string>
using namespace std;
const int MAX = 3;

class Data {
    private:
        int dia, mes, ano;
    public:
        Data() {
            dia = mes = ano = 0;
        }
        void setData(int dia, int mes, int ano) {
            this -> setDia(dia);
            this -> setMes(mes);
            this -> setAno(ano);
            printf("\nSalvada a data: %i/%i/%i\n", this -> dia, this -> mes, this -> ano);
        }

        string getData() {
            string data = to_string(this -> dia) + "/" + to_string(this -> mes) + "/" + to_string(this -> ano);
            return data;
        }

        bool setDia(int dia) {
            bool valido = (1 <= dia) && (dia <= 31);
            if (valido) this -> dia = dia;
            return valido;
        }

        bool setMes(int mes) {
            bool valido = (1 <= mes) && (mes <= 12);
            if (valido) this -> mes = mes;
            return valido;
        }

        bool setAno(int ano) {
            bool valido = (1 <= ano) && (ano <= 2022);
            if (valido) this -> ano = ano;
            return valido;
        }

        int getDia() { return this -> dia; }
        int getMes() { return this -> mes; }
        int getAno() { return this -> ano; }
        

        // Pega o mês por extenso.
        string mesExtenso(int mes) {
            string retorna;
            string meses[] = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
            if (mes > 0 && mes <= 12) {
                retorna = meses[mes - 1];
            } else {
                retorna = "Mes invalido";
            }
            return retorna;
        }
};
