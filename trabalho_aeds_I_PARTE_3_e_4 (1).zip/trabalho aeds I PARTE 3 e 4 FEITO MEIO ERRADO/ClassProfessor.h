// #include "ClassPessoa.h"
// using namespace std;

// class Professor : public Pessoa {
//     protected:
//         string Departamento;
//     public:
//         Professor();

//         void setDepto(string curso);

//         string Origem(); // mesmo que getDepto();
//         void Origem(string ori);
// };

// Professor::Professor(): Pessoa() {
//     Departamento = "";
// }

// void Professor::setDepto(string depto) {
//     printf("\nDigite o departamento: ");
//     cin.ignore();
//     getline(cin, depto);
//     this->Departamento = depto;
//     printf("\nSalvo o curso: %s <-\n", Departamento.c_str());
// }

// string Professor::Origem() {
//     return this->Departamento;
// }

// void Professor::Origem(string ori) {
//     setDepto(ori);
// }