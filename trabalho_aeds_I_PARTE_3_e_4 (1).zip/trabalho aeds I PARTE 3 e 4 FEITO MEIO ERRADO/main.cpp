#include <iostream>
#include "ClassPessoa.h"
using namespace std;
//#define MAX 3

int tamanho = 0;

int menu();
void pesquisa(Pessoa *P[]);
void pesquisaMes(Pessoa *P[]);

int main() {
    
    system("cls");
    
    Pessoa *P[MAX];

    int option;

    do {
        option = menu();
        switch(option) {
            case 0:
                puts("Tchau.");
                break;
            case 1:
                if (tamanho < MAX) {
                    P[tamanho] = new Professor();
                    P[tamanho]->leDados();
                    P[tamanho]->Origem("");
                    tamanho++;
                } else {
                    puts("\nNão ha espaço para mais pessoas.\n");
                }
                break;
            case 2:
                if (tamanho < MAX) {
                    P[tamanho] = new Aluno();
                    P[tamanho]->leDados();
                    P[tamanho]->Origem("");
                    tamanho++;
                } else {
                    puts("\nNão ha espaço para mais pessoas.\n");
                }
                break;
            case 3:
                pesquisa(P);
                break;
            case 4:
                pesquisaMes(P);
                break;
            default:
                puts("\nOpcao invalida!");
                fflush(stdin);

        }


    } while(option != 0);

    return 0;
}


int menu() {
    int op;
    printf("\n\n\tMENU");
    printf("\nOpcao 0: Sair");
    printf("\nOpcao 1: Cadastrar um Professor");
    printf("\nOpcao 2: Cadastrar um Aluno");
    printf("\nOpcao 3: Listar Pessoas");
    printf("\nOpcao 4: Pesquisar pessoas pelo mes");
    printf("\n\nDigite sua opcao: ");
    scanf("%i", &op);
    return op;
}

// pesquisa e imprime todas as pessoas cadastradas.
void pesquisa(Pessoa *P[]) {
    for (int i = 0; i < tamanho; i++) {
        printf("\nPessoa %i: %s", i + 1, P[i]->getNome().c_str());
        printf("\nData de nascimento: %s - %s\n", P[i]->getNascimento().getData().c_str(), P[i]->getNascimentoExtenso().c_str());
        printf("\nOrigem: %s\n", P[i]->Origem().c_str());
    }
}

// pesquisa e imprime todas as pessoas cadastradas que nasceram no mes indicado.
void pesquisaMes(Pessoa *P[]) {
    int mes;
    printf("\nDigite o mes, com um numero de 1 a 12: ");
    scanf("%i", &mes);
    while (mes < 1 || mes > 12) {
        printf("\nMes invalido! Digite novamente: ");
        scanf("%i", &mes);
    }
    printf("\n\n\nPessoas nascidas no mes de %s:\n", P[0]->getNascimento().mesExtenso(mes).c_str());
    for (int i = 0; i < tamanho; i++) {
        if (P[i]->getNascimento().getMes() == mes) {
            P[i]->escreveDados();
        }
    }
}

// Coisas a serem feitas:
// 1- Corrigir a leitura do nome.
