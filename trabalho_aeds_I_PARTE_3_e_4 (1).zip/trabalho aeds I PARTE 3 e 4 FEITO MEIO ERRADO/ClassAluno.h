// #include "ClassPessoa.h"
// using namespace std;

// class Aluno : public Pessoa {
//     protected:
//         string Curso;
//     public:
//         Aluno();

//         void setCurso(string curso);

//         string Origem(); // mesmo que getCurso();
//         void Origem(string ori);
// };

// Aluno::Aluno() {
//     Curso = "";
// }

// void Aluno::setCurso(string curso) {
//     this->Curso = curso;
//     printf("\nSalvo o curso: %s <-\n", Curso.c_str());
// }

// string Aluno::Origem() {
//     return this->Curso;
// }

// void Aluno::Origem(string ori) {
//     setCurso(ori);
// }