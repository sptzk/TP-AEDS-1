#ifndef CLASSES_H_INCLUDED
#define CLASSES_H_INCLUDED
#include <iostream>
#include "ClassData.h"
#include "ClassProfessor.h"
#include "ClassAluno.h"

using namespace std;

class Pessoa {
    private:
        Data Nascimento;
        string Nome;
    public:
        Pessoa();
        
        void setNome(string nome);

        string getNome();

        void setNascimento(Data nascimento);

        Data getNascimento();

        string getNascimentoExtenso();

        void leDados();

        void escreveDados();

        virtual string Origem() = 0;
        virtual void Origem(string ori) = 0;
};

Pessoa::Pessoa() {
    Nome = "";
}

void Pessoa::setNome(string nome) {
    this->Nome = nome;
    printf("\nSalvo o nome: %s <-\n", Nome.c_str());
}

string Pessoa::getNome() {
    return this->Nome;
}

void Pessoa::setNascimento(Data nascimento) {
    this->Nascimento = nascimento;
    printf("\nNascimento dentro da classe: %s", Nascimento.getData().c_str());
}

// Retorna apenas a data
Data Pessoa::getNascimento() {
    return this->Nascimento;
}

// Retorna a data com o mês por extenso
string Pessoa::getNascimentoExtenso() {
    int mes = this->Nascimento.getMes();
    string mesExtenso = this->Nascimento.mesExtenso(mes);
    string retorna;
    if (mes == 0) {
        retorna = "Mes invalido";
    } else {
        retorna = mesExtenso;
    }
    return retorna;
}

//Le os dados da pessoa pelo teclado
void Pessoa::leDados() {
    string nome;
    int dia, mes, ano;
    printf("\nDigite o nome:\n");
    cin.ignore();
    getline(cin, nome);
    printf("\nDigite a data de nascimento (dia/mes/ano): ");
    scanf("%i/%i/%i", &dia, &mes, &ano);
    this->setNome(nome);
    this->Nascimento.setData(dia, mes, ano);
}

// função equilavente à função "void escrevePessoa(Pessoa* pessoa)" pedida na parte 4 do trabalho, porém sem receber parametros
void Pessoa::escreveDados() {
    printf("\nNome: %s", this->Nome.c_str());
    printf("\nNascimento: %s", this->Nascimento.getData().c_str());
    printf("\nOrigem: %s", this->Origem().c_str());
}

class Professor : public Pessoa {
    protected:
        string Departamento;
    public:
        Professor();

        void setDepto(string curso);

        string Origem(); // mesmo que getDepto();
        void Origem(string ori);
};

Professor::Professor(): Pessoa() {
    Departamento = "";
}

void Professor::setDepto(string depto) {
    printf("\nDigite o departamento: ");
    cin.ignore();
    getline(cin, depto);
    this->Departamento = depto;
    printf("\nSalvo o curso: %s <-\n", Departamento.c_str());
}

string Professor::Origem() {
    return this->Departamento;
}

void Professor::Origem(string ori) {
    setDepto(ori);
}

class Aluno : public Pessoa {
    protected:
        string Curso;
    public:
        Aluno();

        void setCurso(string curso);

        string Origem(); // mesmo que getCurso();
        void Origem(string ori);
};

Aluno::Aluno(): Pessoa() {
    Curso = "";
}

void Aluno::setCurso(string curso) {
    printf("\nDigite o curso: ");
    cin.ignore();
    getline(cin, curso);
    this->Curso = curso;
    printf("\nSalvo o curso: %s <-\n", Curso.c_str());
}

string Aluno::Origem() {
    return this->Curso;
}

void Aluno::Origem(string ori) {
    setCurso(ori);
}


#endif // CLASSES_H_INCLUDED;